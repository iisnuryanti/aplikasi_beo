<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
	parent::__construct();
	$this->load->model('MSudi');
	}

	public function index()
	{
		if($this->session->userdata('Login'))
	{
		$data['content']='VBlank';
		$this->load->view('VBackend',$data);

	}
		else
		{
			redirect(site_url('Login'));
		}

	}
		
    
	public function DataTamu()
	{
	
		if($this->uri->segment(4)=='view')
		
		{
			$pax=$this->uri->segment(3);
			$tampil=$this->MSudi->GetDataWhere('tbl_tamu','pax',$pax)->row();
			$data['detail']['pax']= $tampil->pax;
            		$data['detail']['room']= $tampil->room;
            		$data['detail']['nama']= $tampil->nama;
            		$data['detail']['group']= $tampil->group;
            		$data['detail']['date']= $tampil->date;


			$data['content']='VFormUpdateTamu';
		}
		else
		{	
			$data['DataTamu']=$this->MSudi->GetData('tbl_tamu');
			$data['content']='VTamu';
		}


		$this->load->view('VBackend',$data);
	}


	public function VFormAddTamu()
	{
		$data['content']='VFormAddTamu';
		$this->load->view('VBackend',$data);
	}
	public function AddDataTamu()
	{
		 $add['pax']=$this->input->post('pax');
         	 $add['room']= $this->input->post('room');
         	 $add['nama']= $this->input->post('nama'); 
         	 $add['group']= $this->input->post('group');
         	 $add['date']= $this->input->post('date'); 
        	 $this->MSudi->AddData('tbl_tamu',$add);
        	 redirect(site_url('Welcome/DataTamu'));
	}



	public function UpdateDataTamu()
	{
		 $pax=$this->input->post('pax');
		 $update['room']= $this->input->post('room');
         	 $update['nama']= $this->input->post('nama');
         	 $update['group']= $this->input->post('group');
         	 $update['date']= $this->input->post('date');
          	 $this->MSudi->UpdateData('tbl_tamu','pax',$pax,$update);
		 redirect(site_url('Welcome/DataTamu'));
	}


	public function DeleteDataTamu()
	{
		 $pax=$this->uri->segment('3');
        	 $this->MSudi->DeleteData('tbl_tamu','pax',$pax);
        	 redirect(site_url('Welcome/DataTamu'));
	}


	
	public function Logout()
	{
		$this->load->library('session');
		$this->session->unset_userdata('Login');
		redirect(site_url('Login'));
	}

}

