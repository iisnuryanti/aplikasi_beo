
          

<!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Silakan Input</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                 

                 
                 
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <td colspan="6">
      <a href="<?php echo site_url('Welcome/VFormAddTamu'); ?>" class="btn btn-success">Add</a>
    </td><tr>
          <th>Pax</th>
					<th>Room</th>
					<th>Nama</th>
					<th>Group</th>
					<th>Date</th>
					<th></th>
                </tr>
                <tr>
                <?php
	if(!empty($DataTamu))
	{
		foreach($DataTamu as $ReadDS)
		{
	?>

	<tr>
		<td><?php echo $ReadDS->pax; ?></td>
		<td><?php echo $ReadDS->room; ?></td>
		<td><?php echo $ReadDS->nama; ?></td>
		<td><?php echo $ReadDS->group; ?></td>
		<td><?php echo $ReadDS->date; ?></td>
		<td>
			<a href="<?php echo site_url('Welcome/DataTamu/'.$ReadDS->pax.'/view'); ?>" class="btn btn-info">Update</a>
			<a href="<?php echo site_url('Welcome/DeleteDataTamu/'.$ReadDS->pax); ?>" class="btn btn-info">Delete</a>
		</td>
	 </tr>

  <?php   
    }
  }
  ?>
                <tr
                </tr>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->