<form action="<?php echo site_url('Welcome/AddDataTamu'); ?>" method="post">
	Pax<input type="text" name="pax"><br>
	Room<input type="text" name="room"><br>
	Nama<input type="text" name="nama"><br>
	Group<input type="text" name="group"><br>
	Date<input type="text" name="date"><br>
	<input type="submit" name="simpan" value="Simpan " class="btn btn-success">	         
</form>



