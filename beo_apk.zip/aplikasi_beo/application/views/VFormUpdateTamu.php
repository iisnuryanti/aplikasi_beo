<form action="<?php echo site_url('Welcome/UpdateDataTamu'); ?>" method="post">
<table>
	<tr>
		<td>Pax</td>
		<td>:</td>
		<td>
			<input type="text" name="pax" value="<?php echo $detail['pax']; ?>">
		</td>
	</tr>
	<tr>
		<td>Room</td>
		<td>:</td>
		<td>
			<input type="text" name="room" value="<?php echo $detail['room']; ?>">
		</td>
	</tr>
	<tr>
		<td>Nama</td>
		<td>:</td>
		<td>
			<input type="text" name="nama" value="<?php echo $detail['nama']; ?>">
		</td>
	</tr>
	<tr>
		<td>Group</td>
		<td>:</td>
		<td>
			<input type="text" name="group" value="<?php echo $detail['group']; ?>">
		</td>
	</tr>
	<tr>
		<td>Date</td>
		<td>:</td>
		<td>
			<input type="text" name="date" value="<?php echo $detail['date']; ?>">
		</td>
	</tr>
	<tr>
		<td colspan="3" align="right">
			<input type="submit" name="btn_simpan" value="Simpan " class="btn btn-success">
		</td>
	</tr>
</table>
</form>